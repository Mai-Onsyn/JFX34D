package HCloudbyte.ui;

import HCloudbyte.ui.refactored.RefactoredApp;
import javafx.application.Application;

public class Main {
    public static void main(String[] args) {
        Application.launch(RefactoredApp.class);
    }
}